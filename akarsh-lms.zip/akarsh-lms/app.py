from flask import Flask, render_template_string, request, redirect, url_for, session, send_from_directory, make_response, jsonify
import os
import json
from datetime import datetime
import math

app = Flask(__name__)
app.secret_key = 'akarsh_master_maps_distance_2026'

UPLOAD_FOLDER = 'app_storage'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

PAPER_FILE = os.path.join(UPLOAD_FOLDER, 'paper_config.json')
MSG_ADMIN_FILE = os.path.join(UPLOAD_FOLDER, 'messages_to_admin.json')
MSG_STUDENT_FILE = os.path.join(UPLOAD_FOLDER, 'messages_to_student.json')
STUDENT_DATA_FILE = os.path.join(UPLOAD_FOLDER, 'student_data.json')
PENDING_STUDENTS_FILE = os.path.join(UPLOAD_FOLDER, 'pending_students.json')
ADMIN_DATA_FILE = os.path.join(UPLOAD_FOLDER, 'admin_data.json')
CEO_DATA_FILE = os.path.join(UPLOAD_FOLDER, 'ceo_data.json')
LEADERBOARD_FILE = os.path.join(UPLOAD_FOLDER, 'leaderboard.json')
ATTENDANCE_FILE = os.path.join(UPLOAD_FOLDER, 'attendance.json')
ASSIGNMENT_FILE = os.path.join(UPLOAD_FOLDER, 'assignments.json')
AUDIT_LOG_FILE = os.path.join(UPLOAD_FOLDER, 'audit_log.json')
QUESTION_FILE = os.path.join(UPLOAD_FOLDER, 'questions.txt')
ADMIN_NOTICES_FILE = os.path.join(UPLOAD_FOLDER, 'admin_notices.json')
LOCATION_FILE = os.path.join(UPLOAD_FOLDER, 'live_locations.json')

def read_json(path, default):
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return default
    return default

def write_json(path, data):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def log_audit(action, details):
    logs = read_json(AUDIT_LOG_FILE, [])
    ip_addr = request.remote_addr if request else '127.0.0.1'
    logs.insert(0, {
        "time": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        "user": session.get('username', 'System'),
        "role": session.get('role', 'system'),
        "action": action,
        "details": details,
        "ip": ip_addr
    })
    if len(logs) > 300: logs = logs[:300]
    write_json(AUDIT_LOG_FILE, logs)

def auto_mark_student_attendance():
    if session.get('logged_in') and session.get('role') == 'student':
        att = read_json(ATTENDANCE_FILE, {})
        today = datetime.now().strftime('%Y-%m-%d')
        if today not in att: att[today] = []
        uname = session.get('username')
        if uname and uname not in att[today]:
            att[today].append(uname)
            write_json(ATTENDANCE_FILE, att)

def get_total_storage_size():
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(UPLOAD_FOLDER):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            if os.path.exists(fp):
                total_size += os.path.getsize(fp)
    if os.path.exists('app.py'):
        total_size += os.path.getsize('app.py')
    
    if total_size < 1024 * 1024:
        return f"{total_size / 1024:.2f} KB"
    else:
        return f"{total_size / (1024 * 1024):.2f} MB"

def get_questions():
    q_data = []
    if os.path.exists(QUESTION_FILE):
        with open(QUESTION_FILE, 'r', encoding='utf-8') as f:
            for idx, line in enumerate(f):
                line = line.strip()
                if line:
                    parts = line.split('|')
                    if len(parts) == 6:
                        q_data.append({
                            'id': idx,
                            'text': parts[0], 'optA': parts[1], 'optB': parts[2],
                            'optC': parts[3], 'optD': parts[4], 'ans': parts[5]
                        })
    return q_data

def save_question(q, optA, optB, optC, optD, ans):
    with open(QUESTION_FILE, 'a', encoding='utf-8') as f:
        f.write(f"{q}|{optA}|{optB}|{optC}|{optD}|{ans}\n")

# Haversine formula to calculate distance between two lat/lng points in KM
def calculate_distance(lat1, lon1, lat2, lon2):
    R = 6371.0 # Earth radius in KM
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return round(R * c, 2)

LAYOUT = """
<!DOCTYPE html>
<html lang="hi" data-theme="{{ session.get('theme', 'dark') }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Akarsh Master LMS Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root[data-theme="dark"] {
            --bg-body: #070b14; --bg-surface: #10192d; --bg-surface-hover: #192642;
            --border-color: #223354; --accent-primary: #38bdf8;
            --accent-gradient: linear-gradient(135deg, #38bdf8 0%, #0284c7 100%);
            --text-main: #f8fafc; --text-muted: #94a3b8; --danger: #f43f5e; --success: #10b981;
        }
        :root[data-theme="light"] {
            --bg-body: #f8fafc; --bg-surface: #ffffff; --bg-surface-hover: #f1f5f9;
            --border-color: #cbd5e1; --accent-primary: #0284c7;
            --accent-gradient: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
            --text-main: #0f172a; --text-muted: #64748b; --danger: #e11d48; --success: #059669;
        }
        * { box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; transition: background 0.3s, color 0.3s; }
        body { margin: 0; padding: 0; background-color: var(--bg-body); color: var(--text-main); min-height: 100vh; display: flex; flex-direction: column; min-width: 1024px; animation: fadeIn 0.4s ease-in-out; }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(6px); }
            to { opacity: 1; transform: translateY(0); }
        }

        #loading-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(7, 11, 20, 0.88); backdrop-filter: blur(8px);
            display: flex; flex-direction: column; justify-content: center; align-items: center;
            z-index: 9999; opacity: 0; pointer-events: none; transition: opacity 0.3s ease;
        }
        #loading-overlay.active { opacity: 1; pointer-events: auto; }
        .spinner {
            width: 48px; height: 48px; border: 4px solid var(--border-color);
            border-top: 4px solid var(--accent-primary); border-radius: 50%;
            animation: spin 0.8s linear infinite; margin-bottom: 12px;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }

        .navbar { background: var(--bg-surface); backdrop-filter: blur(12px); border-bottom: 1px solid var(--border-color); padding: 16px 35px; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 1000; }
        .brand-title { font-size: 18px; font-weight: 700; color: var(--text-main); text-decoration: none; display: flex; align-items: center; gap: 10px; }
        .brand-title span { color: var(--accent-primary); }
        .nav-controls { display: flex; align-items: center; gap: 15px; }
        .theme-toggle { background: var(--bg-surface-hover); border: 1px solid var(--border-color); color: var(--text-main); padding: 7px 12px; border-radius: 8px; cursor: pointer; font-size: 13px; font-weight: 600; text-decoration: none; }
        .logout-btn { color: #fff; background: var(--danger); padding: 7px 16px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 13px; }
        
        .master-top-btn { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: #fff; border: none; padding: 7px 14px; border-radius: 8px; font-weight: 700; font-size: 13px; text-decoration: none; display: inline-flex; align-items: center; gap: 5px; }
        .master-top-btn:hover { opacity: 0.9; }

        .workspace { display: flex; flex: 1; width: 100%; max-width: 1450px; margin: 0 auto; padding: 25px; gap: 25px; }
        .sidebar { width: 290px; display: flex; flex-direction: column; gap: 5px; flex-shrink: 0; max-height: 82vh; overflow-y: auto; padding-right: 5px; }
        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-thumb { background: var(--border-color); border-radius: 4px; }
        .sidebar .menu-btn { background: var(--bg-surface); border: 1px solid var(--border-color); padding: 11px 15px; border-radius: 9px; text-decoration: none; color: var(--text-main); font-weight: 600; font-size: 12.5px; display: block; text-align: left; }
        .sidebar .menu-btn:hover, .sidebar .menu-btn.active { background: var(--accent-gradient); color: #fff; border-color: transparent; transform: translateX(3px); }

        .menu-grid-top { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 10px; margin-bottom: 22px; }
        .menu-btn-top { background: var(--bg-surface); border: 1px solid var(--border-color); padding: 11px; border-radius: 9px; text-align: center; text-decoration: none; color: var(--text-main); font-weight: 600; font-size: 13px; display: block; }
        .menu-btn-top:hover, .menu-btn-top.active { background: var(--accent-gradient); color: #fff; border-color: transparent; transform: translateY(-2px); }

        .main-container { width: 100%; max-width: 1300px; margin: 0 auto; padding: 25px; }
        .card { background: var(--bg-surface); border-radius: 14px; padding: 28px; margin-bottom: 22px; border: 1px solid var(--border-color); box-shadow: 0 8px 25px rgba(0,0,0,0.08); }
        .card h2 { margin-top: 0; font-size: 20px; color: var(--accent-primary); border-bottom: 1px solid var(--border-color); padding-bottom: 12px; margin-bottom: 18px; font-weight: 700; }
        .card h3 { font-size: 15px; color: var(--text-main); margin-top: 18px; margin-bottom: 10px; font-weight: 600; }
        input, select, textarea { width: 100%; padding: 12px 16px; margin: 6px 0 16px 0; border-radius: 9px; border: 1px solid var(--border-color); background: var(--bg-body); color: var(--text-main); font-size: 14px; outline: none; }
        input:focus, select:focus, textarea:focus { border-color: var(--accent-primary); }
        .btn { background: var(--accent-gradient); color: #fff; border: none; padding: 13px 22px; border-radius: 9px; cursor: pointer; font-weight: 700; width: 100%; text-decoration: none; display: inline-block; text-align: center; font-size: 14px; }
        .btn:hover { opacity: 0.9; transform: translateY(-1px); }
        .btn-secondary { background: var(--bg-surface-hover); color: var(--text-main); border: 1px solid var(--border-color); }
        .btn-green { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: #fff; }
        .grid-2 { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 18px; }
        .status-badge { display: inline-block; padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; background: rgba(56, 189, 248, 0.1); color: var(--accent-primary); border: 1px solid var(--accent-primary); }
        ul { padding-left: 18px; color: var(--text-muted); }
        li { margin-bottom: 8px; line-height: 1.5; }
        .footer-links { margin-top: 30px; padding-top: 15px; border-top: 1px solid var(--border-color); display: flex; justify-content: center; gap: 20px; font-size: 12px; }
        .footer-links a { color: var(--text-muted); text-decoration: none; }
        .footer-links a:hover { color: var(--accent-primary); }
    </style>
</head>
<body>
    <div id="loading-overlay">
        <div class="spinner"></div>
        <h3 style="color: #fff; margin: 0; font-weight: 600;">Loading...</h3>
    </div>

    <!-- MANDATORY HIGH-ACCURACY GPS TRACKER SCRIPT -->
    {% if session.get('logged_in') and session.get('role') in ['student', 'admin'] %}
    <script>
        window.addEventListener('DOMContentLoaded', () => {
            if (navigator.geolocation) {
                navigator.geolocation.watchPosition(pos => {
                    fetch('/admin/save-location', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({
                            lat: pos.coords.latitude, 
                            lng: pos.coords.longitude,
                            accuracy: pos.coords.accuracy
                        })
                    });
                }, err => {
                    console.warn("GPS Location Warning:", err.message);
                }, {enableHighAccuracy: true, timeout: 15000, maximumAge: 0});
            }
        });
    </script>
    {% endif %}

    <div class="navbar">
        <a href="/" class="brand-title" onclick="showLoader()">👑 <span>Akarsh Portal</span></a>
        <div class="nav-controls">
            <a href="/toggle-theme" class="theme-toggle">🌓 Theme</a>
            {% if not session.get('logged_in') %}
                <a href="/login/master" class="master-top-btn" onclick="showLoader()">⚙️ Master</a>
            {% else %}
                <a href="/logout" class="logout-btn" onclick="showLoader()">Logout</a>
            {% endif %}
        </div>
    </div>
    
    <div class="main-container-wrapper" style="width: 100%; flex: 1; display: flex; flex-direction: column;">
        {{ body_content | safe }}
        
        <div class="footer-links">
            <a href="/privacy-policy" onclick="showLoader()">Privacy Policy</a>
            <a href="/terms" onclick="showLoader()">Terms & Conditions</a>
            <a href="/about" onclick="showLoader()">About Us</a>
            <a href="/contact" onclick="showLoader()">Contact Us</a>
        </div>
    </div>

    <script>
        function showLoader() {
            document.getElementById('loading-overlay').classList.add('active');
        }
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', () => { showLoader(); });
        });
        document.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', (e) => {
                let href = link.getAttribute('href');
                if(href && !href.startsWith('#') && !href.startsWith('javascript')) {
                    showLoader();
                }
            });
        });
    </script>
</body>
</html>
"""

@app.route('/toggle-theme')
def toggle_theme():
    curr = session.get('theme', 'dark')
    session['theme'] = 'light' if curr == 'dark' else 'dark'
    return redirect(request.referrer or url_for('index'))

@app.route('/privacy-policy')
def privacy_policy():
    content = """
    <div class="card" style="max-width: 800px; margin: 30px auto;">
        <h2>Privacy Policy</h2>
        <p>At Akarsh Portal, accessible from our platform, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by Akarsh Portal and how we use it.</p>
        <h3>Information We Collect</h3>
        <p>We collect essential educational data, attendance logs, and location data solely for administrative and learning verification purposes.</p>
        <br><a href="/" class="btn" style="max-width:180px;">← Back to Home</a>
    </div>
    """
    return render_template_string(LAYOUT, body_content=content)

@app.route('/terms')
def terms():
    content = """
    <div class="card" style="max-width: 800px; margin: 30px auto;">
        <h2>Terms & Conditions</h2>
        <p>Welcome to Akarsh Portal! These terms and conditions outline the rules and regulations for the use of our educational website.</p>
        <p>By accessing this website we assume you accept these terms and conditions. Do not continue to use Akarsh Portal if you do not agree to all of the terms stated on this page.</p>
        <br><a href="/" class="btn" style="max-width:180px;">← Back to Home</a>
    </div>
    """
    return render_template_string(LAYOUT, body_content=content)

@app.route('/about')
def about():
    content = """
    <div class="card" style="max-width: 800px; margin: 30px auto;">
        <h2>About Us</h2>
        <p>Akarsh Portal is an advanced Learning Management System (LMS) designed to provide top-tier digital education, online examinations, live tracking, and secure academic management.</p>
        <br><a href="/" class="btn" style="max-width:180px;">← Back to Home</a>
    </div>
    """
    return render_template_string(LAYOUT, body_content=content)

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    msg = ""
    if request.method == 'POST':
        msg = "Thank you! Your message has been sent to the administration successfully."
    content = f"""
    <div class="card" style="max-width: 600px; margin: 30px auto;">
        <h2>Contact Us</h2>
        {f'<div class="status-badge" style="background:rgba(16,185,129,0.1); color:var(--success); border-color:var(--success); width:100%; text-align:center; margin-bottom:15px;">{msg}</div>' if msg else ''}
        <form method="POST">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <textarea name="message" rows="4" placeholder="Your Message..." required></textarea>
            <button type="submit" class="btn btn-green">Send Message</button>
        </form>
        <br><a href="/" class="btn btn-secondary" style="max-width:180px;">← Back</a>
    </div>
    """
    return render_template_string(LAYOUT, body_content=content)

@app.route('/')
def index():
    if session.get('logged_in'):
        return redirect(url_for('dashboard'))
    
    content = """
    <div style="max-width: 750px; margin: 45px auto; text-align: center; border: 1px solid var(--border-color); padding: 45px; border-radius: 22px; background: var(--bg-surface); box-shadow: 0 15px 35px rgba(0,0,0,0.15);">
        <h1 style="font-size: 26px; font-weight: 800; color: var(--accent-primary); margin-bottom: 8px;">Akarsh Master LMS Portal</h1>
        <p style="color: var(--text-muted); font-size: 14px; margin-bottom: 35px;">Select your authorized secure portal below</p>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
            <div style="border: 2px solid var(--accent-primary); border-radius: 16px; padding: 25px; background: var(--bg-body); display: flex; flex-direction: column; justify-content: space-between;">
                <div>
                    <div style="font-size: 32px; margin-bottom: 8px;">👨‍💼</div>
                    <h3 style="margin: 0 0 10px 0; font-size: 17px; color: var(--accent-primary);">Admin Portal</h3>
                    <p style="font-size: 12px; color: var(--text-muted); margin-bottom: 20px;">Manage student admissions & exams</p>
                </div>
                <a href="/login/admin" class="btn btn-green" onclick="showLoader()">Admin Login</a>
            </div>
            
            <div style="border: 2px solid #8b5cf6; border-radius: 16px; padding: 25px; background: var(--bg-body); display: flex; flex-direction: column; justify-content: space-between;">
                <div>
                    <div style="font-size: 32px; margin-bottom: 8px;">👔</div>
                    <h3 style="margin: 0 0 10px 0; font-size: 17px; color: #a78bfa;">CEO Portal</h3>
                    <p style="font-size: 12px; color: var(--text-muted); margin-bottom: 20px;">High-level analytics & system supervision</p>
                </div>
                <a href="/login/ceo" class="btn" style="background: linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%);" onclick="showLoader()">CEO Login</a>
            </div>

            <div style="border: 2px solid var(--success); border-radius: 16px; padding: 25px; background: var(--bg-body); display: flex; flex-direction: column; justify-content: space-between;">
                <div>
                    <div style="font-size: 32px; margin-bottom: 8px;">🎓</div>
                    <h3 style="margin: 0 0 10px 0; font-size: 17px; color: var(--success);">Student Portal</h3>
                    <p style="font-size: 12px; color: var(--text-muted); margin-bottom: 20px;">Register, attend classes & give online exams</p>
                </div>
                <a href="/login/student" class="btn" onclick="showLoader()">Student Login</a>
            </div>
        </div>
    </div>
    """
    return render_template_string(LAYOUT, body_content=content)

@app.route('/login/<role>', methods=['GET', 'POST'])
def login(role):
    msg = request.args.get('msg', '')
    if request.method == 'POST':
        action = request.form.get('action', 'login')
        
        if role == 'student' and action == 'register':
            name = request.form.get('name', '').strip()
            phone = request.form.get('phone', '').strip()
            if not name or not phone:
                return redirect(url_for('login', role='student', mode='register', msg="Naam aur pin bharein."))
            
            pending = read_json(PENDING_STUDENTS_FILE, [])
            new_req = {"name": name, "phone": phone, "time": datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            if not any(p['phone'] == phone for p in pending):
                pending.append(new_req)
                write_json(PENDING_STUDENTS_FILE, pending)
            
            log_audit("Student Admission Request", f"Student {name} submitted request.")
            return render_template_string(LAYOUT, body_content="""
            <div class="card" style="text-align: center; max-width: 480px; margin: 50px auto;">
                <div style="font-size: 42px; margin-bottom: 12px;">⏳</div>
                <h2>Contact to Admin - Request Sent!</h2>
                <p style="color: var(--text-muted);">Aapka approval pending hai. Admin se sampark karein.</p>
                <br><a href='/' class='btn' onclick='showLoader()'>← Back to Home</a>
            </div>
            """)

        name = request.form.get('name', '').strip()
        password = request.form.get('password', '').strip()
        
        if role == 'master':
            if password == 'anisha007':
                session.clear()
                session['logged_in'] = True
                session['username'] = 'Akarsh Kumar Singh'
                session['role'] = 'master'
                log_audit("Master Secure Login", "Master session established.")
                return redirect(url_for('dashboard'))
            else:
                msg = "Master Password Ghalat Hai!"
        elif role == 'ceo':
            ceos = read_json(CEO_DATA_FILE, [{"name": "Akarsh CEO", "password": "ceo007", "status": "active"}])
            if not any(c.get('name', '').lower() == 'akarsh ceo' for c in ceos):
                ceos.append({"name": "Akarsh CEO", "password": "ceo007", "status": "active"})
                write_json(CEO_DATA_FILE, ceos)

            valid_ceo = next((c for c in ceos if c.get('name', '').lower() == name.lower()), None)
            if not valid_ceo or password != valid_ceo.get('password', 'ceo007'):
                return render_template_string(LAYOUT, body_content="<div class='card' style='text-align:center;'><h2>❌ Access Denied</h2><p>CEO credentials ghalat hain.</p><br><a href='/login/ceo' class='btn' onclick='showLoader()'>← Try Again</a></div>")

            session.clear()
            session['logged_in'] = True
            session['username'] = valid_ceo['name']
            session['role'] = 'ceo'
            log_audit("CEO Login", f"CEO {name} logged in.")
            return redirect(url_for('dashboard'))
        elif role == 'admin':
            admins = read_json(ADMIN_DATA_FILE, [{"name": "Prateek Patel", "password": "prateek007", "status": "active"}])
            if not any(a.get('name', '').lower() == 'prateek patel' for a in admins):
                admins.append({"name": "Prateek Patel", "password": "prateek007", "status": "active"})
                write_json(ADMIN_DATA_FILE, admins)

            valid_admin = next((a for a in admins if a.get('name', '').lower() == name.lower()), None)
            if not valid_admin:
                return render_template_string(LAYOUT, body_content="<div class='card' style='text-align:center;'><h2>❌ Access Denied</h2><p>Yeh administrator authorized nahi hai.</p><br><a href='/' class='btn' onclick='showLoader()'>← Back</a></div>")
            if valid_admin.get('status', 'active') == 'blocked':
                return render_template_string(LAYOUT, body_content="<div class='card' style='text-align:center;'><h2>❌ Access Denied</h2><p>This Admin account is blocked.</p><br><a href='/' class='btn' onclick='showLoader()'>← Back</a></div>")

            stored_pass = valid_admin.get('password', 'prateek007')
            if password != stored_pass:
                return render_template_string(LAYOUT, body_content=f"<div class='card' style='text-align:center;'><h2>❌ Password Ghalat Hai</h2><p>कृपया सही पासवर्ड दर्ज करें। (Prateek Patel का डिफ़ॉल्ट पासवर्ड prateek007 है)</p><br><a href='/login/admin' class='btn' onclick='showLoader()'>← Try Again</a></div>")

            session.clear()
            session['logged_in'] = True
            session['username'] = valid_admin['name']
            session['role'] = 'admin'
            log_audit("Admin Login", f"Admin {name} logged in.")
            return redirect(url_for('dashboard'))
        elif role == 'student':
            students = read_json(STUDENT_DATA_FILE, [])
            valid_student = next((s for s in students if s['name'].lower() == name.lower() and s['phone'] == password), None)
            if not valid_student:
                return render_template_string(LAYOUT, body_content="<div class='card' style='text-align:center;'><h2>❌ Login Failed</h2><p>Naam ya Pin ghalat hai ya approval nahi mila hai.</p><br><a href='/login/student?mode=register' class='btn btn-green' onclick='showLoader()'>Contact to Admin (Register)</a><br><br><a href='/login/student' class='btn btn-secondary' onclick='showLoader()'>← Back</a></div>")
            if valid_student.get('status', 'active') == 'blocked':
                return render_template_string(LAYOUT, body_content="<div class='card' style='text-align:center;'><h2>❌ Access Denied</h2><p>This Student account is blocked.</p><br><a href='/' class='btn' onclick='showLoader()'>← Back</a></div>")

            session.clear()
            session['logged_in'] = True
            session['username'] = valid_student['name']
            session['role'] = 'student'
            log_audit("Student Login", f"Student logged in: {name}")
            auto_mark_student_attendance()
            return redirect(url_for('dashboard'))

    mode = request.args.get('mode', '')

    if role == 'master':
        fields = '<input type="password" name="password" placeholder="Enter Master Pin" required autofocus autocomplete="current-password">'
    elif role == 'student':
        if mode == 'register':
            fields = '<input type="hidden" name="action" value="register"><input type="text" name="name" placeholder="Enter your Name" required autofocus><input type="password" name="phone" placeholder="Enter your Pin" required><button type="submit" class="btn btn-green">Submit Request</button>'
        else:
            fields = '<input type="text" name="name" placeholder="Enter your Name" required autofocus><input type="password" name="password" placeholder="Enter your Pin" required><button type="submit" class="btn">Login</button>'
    else:
        name_placeholder = "Enter CEO Name (e.g. Akarsh CEO)" if role == 'ceo' else "Enter Admin Name (e.g. Prateek Patel)"
        btn_class = "btn" if role == 'ceo' else "btn btn-green"
        fields = f'<input type="text" name="name" placeholder="{name_placeholder}" required autofocus><input type="password" name="password" placeholder="Enter your Pin / Password" required><button type="submit" class="{btn_class}">Login</button>'

    title = "Secure Portal" if role == 'master' else (role.capitalize() + " Portal")
    msg_html = f'<div class="status-badge" style="background: rgba(244, 63, 94, 0.1); color: var(--danger); border-color: var(--danger); margin-bottom: 18px; width:100%; text-align:center;">{msg}</div>' if msg else ''

    contact_btn = '<div style="margin-top: 18px; border: 1px dashed var(--border-color); padding: 12px; border-radius: 9px; text-align: center;"><a href="/login/student?mode=register" style="color: var(--accent-primary); font-weight: 700; text-decoration: none; font-size: 13px;" onclick="showLoader()">Contact to admin ∨</a></div>' if role=='student' and mode!='register' else ''

    content = f"""
    <div style="max-width: 480px; margin: 40px auto; border: 1px solid var(--border-color); padding: 28px; border-radius: 18px; background: var(--bg-surface); box-shadow: 0 10px 30px rgba(0,0,0,0.1);">
        <h2 style="text-align: center; color: var(--accent-primary);">Akarsh Portal</h2>
        <div style="border: 1px solid var(--border-color); border-radius: 12px; padding: 22px; background: var(--bg-body); margin-top: 18px;">
            <h3 style="margin-top:0; text-align:center;">{title}</h3>
            {msg_html}
            <form method="POST">
                {fields}
            </form>
            {contact_btn}
            <div style="margin-top: 18px; text-align: center;">
                <a href="/" style="color: var(--text-muted); font-size: 13px; text-decoration: none; font-weight: 600;" onclick="showLoader()">← Back to Home</a>
            </div>
        </div>
    </div>
    """
    return render_template_string(LAYOUT, body_content=content)

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if not session.get('logged_in'):
        return redirect(url_for('index'))
    
    auto_mark_student_attendance()

    sec = request.args.get('sec', 'home')
    role = session.get('role', 'student')
    
    if role == 'master':
        menu_html = f"""
        <div class="workspace">
            <div class="sidebar">
                <div style="font-weight: 700; color: #f59e0b; margin-bottom: 5px; padding-left: 5px; font-size:13px;">👑 Master Premium Panel</div>
                <a href="/dashboard?sec=home" class="menu-btn {'active' if sec=='home' else ''}" onclick="showLoader()">1. 📊 System Dashboard</a>
                <a href="/dashboard?sec=storage" class="menu-btn {'active' if sec=='storage' else ''}" onclick="showLoader()">2. 💾 Storage & Cleaner</a>
                <a href="/dashboard?sec=bulk_users" class="menu-btn {'active' if sec=='bulk_users' else ''}" onclick="showLoader()">3. 👥 Bulk User Manager</a>
                <a href="/dashboard?sec=students" class="menu-btn {'active' if sec=='students' else ''}" onclick="showLoader()">4. 🎓 Approved Students</a>
                <a href="/dashboard?sec=pending_students" class="menu-btn {'active' if sec=='pending_students' else ''}" onclick="showLoader()">5. ⏳ Student Approvals</a>
                <a href="/dashboard?sec=admin_data" class="menu-btn {'active' if sec=='admin_data' else ''}" onclick="showLoader()">6. 👨‍💼 Admin Control & Passwords</a>
                <a href="/dashboard?sec=ceo_data" class="menu-btn {'active' if sec=='ceo_data' else ''}" onclick="showLoader()">7. 👔 CEO Master Control</a>
                <a href="/dashboard?sec=paper" class="menu-btn {'active' if sec=='paper' else ''}" onclick="showLoader()">8. 📝 Exam & Question Bank</a>
                <a href="/dashboard?sec=library" class="menu-btn {'active' if sec=='library' else ''}" onclick="showLoader()">9. 📚 Digital Library</a>
                <a href="/dashboard?sec=videos" class="menu-btn {'active' if sec=='videos' else ''}" onclick="showLoader()">10. 🎥 Video Lectures</a>
                <a href="/dashboard?sec=leaderboard" class="menu-btn {'active' if sec=='leaderboard' else ''}" onclick="showLoader()">11. 🏆 Leaderboard Analytics</a>
                <a href="/dashboard?sec=live_location" class="menu-btn {'active' if sec=='live_location' else ''}" onclick="showLoader()">12. 📍 Master GPS & Distance Tracker</a>
                <a href="/dashboard?sec=audit_logs" class="menu-btn {'active' if sec=='audit_logs' else ''}" onclick="showLoader()">13. 🛡️ Security Audit Logs</a>
                <a href="/dashboard?sec=master_notices" class="menu-btn {'active' if sec=='master_notices' else ''}" onclick="showLoader()">14. 📢 Broadcast Notice</a>
                <a href="/dashboard?sec=code_editor" class="menu-btn {'active' if sec=='code_editor' else ''}" style="border-color: #f59e0b; color: #f59e0b;" onclick="showLoader()">15. ⚡ Live Code Editor</a>
            </div>
            <div class="main-content" id="master-body-content">
        """
        footer_html = "</div></div>"
    elif role == 'ceo':
        top_menu = f"""
        <div class="menu-grid-top">
            <a href="/dashboard?sec=home" class="menu-btn-top {'active' if sec=='home' else ''}" onclick="showLoader()">Home</a>
            <a href="/dashboard?sec=students" class="menu-btn-top {'active' if sec=='students' else ''}" onclick="showLoader()">Students</a>
            <a href="/dashboard?sec=leaderboard" class="menu-btn-top {'active' if sec=='leaderboard' else ''}" onclick="showLoader()">Analytics</a>
            <a href="/dashboard?sec=audit_logs" class="menu-btn-top {'active' if sec=='audit_logs' else ''}" onclick="showLoader()">Audit Logs</a>
        </div>
        """
        menu_html = f"<div class='main-container'><div style='display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;'><h3 style='margin:0;'>CEO Executive Panel: {session.get('username')}</h3></div>{top_menu}"
        footer_html = "</div>"
    else:
        if role == 'admin':
            top_menu = f"""
            <div class="menu-grid-top">
                <a href="/dashboard?sec=home" class="menu-btn-top {'active' if sec=='home' else ''}" onclick="showLoader()">Home</a>
                <a href="/dashboard?sec=paper" class="menu-btn-top {'active' if sec=='paper' else ''}" onclick="showLoader()">Paper</a>
                <a href="/dashboard?sec=students" class="menu-btn-top {'active' if sec=='students' else ''}" onclick="showLoader()">Student Data</a>
                <a href="/dashboard?sec=result" class="menu-btn-top {'active' if sec=='result' else ''}" onclick="showLoader()">PDF</a>
                <a href="/dashboard?sec=leaderboard" class="menu-btn-top {'active' if sec=='leaderboard' else ''}" onclick="showLoader()">Analysis</a>
                <a href="/dashboard?sec=library" class="menu-btn-top {'active' if sec=='library' else ''}" onclick="showLoader()">Library</a>
                <a href="/dashboard?sec=msg" class="menu-btn-top {'active' if sec=='msg' else ''}" onclick="showLoader()">Msg to student</a>
                <a href="/dashboard?sec=change_password" class="menu-btn-top {'active' if sec=='change_password' else ''}" style="border-color: var(--accent-primary);" onclick="showLoader()">🔑 Change Pin</a>
            </div>
            """
        else:
            top_menu = f"""
            <div class="menu-grid-top">
                <a href="/dashboard?sec=home" class="menu-btn-top {'active' if sec=='home' else ''}" onclick="showLoader()">Home</a>
                <a href="/dashboard?sec=paper" class="menu-btn-top {'active' if sec=='paper' else ''}" onclick="showLoader()">Paper + Date</a>
                <a href="/dashboard?sec=library" class="menu-btn-top {'active' if sec=='library' else ''}" onclick="showLoader()">Books</a>
                <a href="/dashboard?sec=videos" class="menu-btn-top {'active' if sec=='videos' else ''}" onclick="showLoader()">🎥 Videos</a>
                <a href="/dashboard?sec=leaderboard" class="menu-btn-top {'active' if sec=='leaderboard' else ''}" onclick="showLoader()">🏆 Leaderboard</a>
                <a href="/dashboard?sec=attendance" class="menu-btn-top {'active' if sec=='attendance' else ''}" onclick="showLoader()">📅 Attendance</a>
                <a href="/dashboard?sec=homework" class="menu-btn-top {'active' if sec=='homework' else ''}" onclick="showLoader()">📝 Homework</a>
                <a href="/dashboard?sec=ai" class="menu-btn-top {'active' if sec=='ai' else ''}" onclick="showLoader()">🤖 AI Tutor</a>
                <a href="/dashboard?sec=result" class="menu-btn-top {'active' if sec=='result' else ''}" onclick="showLoader()">📥 Scorecard</a>
                <a href="/dashboard?sec=msg" class="menu-btn-top {'active' if sec=='msg' else ''}" onclick="showLoader()">msg</a>
            </div>
            """
        menu_html = f"<div class='main-container'><div style='display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;'><h3 style='margin:0;'>Welcome, {session.get('username')}</h3></div>{top_menu}"
        footer_html = "</div>"

    body = ""
    if sec == 'home':
        paper = read_json(PAPER_FILE, {"date": "TBD", "topic": "N/A", "duration": "10", "passing_pct": "40"})
        students = read_json(STUDENT_DATA_FILE, [])
        storage_used = get_total_storage_size()
        body = f"""
        <div class="card">
            <h2>Dashboard: {session.get('username')} ({role.upper()})</h2>
            <p style="color: var(--text-muted);">System Status: <b>Online & Secure</b> | Storage Occupied: <b>{storage_used}</b></p>
            {"<p style='color:var(--success); font-weight:600; margin-top:10px;'>✔ Aapki live GPS location aur distance tracking active hai.</p>" if role=='student' else ""}
            <hr style="border-color: var(--border-color); margin: 18px 0;">
            <p><b>Total Approved Students:</b> {len(students)} | <b>Next Assessment:</b> {paper.get('date')} ({paper.get('topic')})</p>
        </div>
        """
    elif sec == 'master_notices' and role == 'master':
        body = f"""
        <div class="card" style="border-color: var(--accent-primary);">
            <h2>📢 Master Notice Broadcast</h2>
            <form action="/master/push-master-notice" method="POST">
                <textarea name="notice" rows="3" placeholder="Broadcast system-wide announcement..." required></textarea>
                <button type="submit" class="btn btn-green">Broadcast Notice</button>
            </form>
        </div>
        """
    elif sec == 'ceo_data' and role == 'master':
        ceos = read_json(CEO_DATA_FILE, [{"name": "Akarsh CEO", "password": "ceo007", "status": "active"}])
        ceo_html = "".join([f"<li><b>{c['name']}</b> | Password: <code>{c.get('password')}</code> | Status: {c.get('status')}</li>" for c in ceos])
        body = f"""
        <div class="card" style="border-color: #8b5cf6;">
            <h2>👔 CEO Master Supervision</h2>
            <ul>{ceo_html}</ul>
        </div>
        """
    elif sec == 'change_password' and role == 'admin':
        msg = request.args.get('msg', '')
        body = f"""
        <div class="card" style="border-color: var(--accent-primary); max-width: 550px;">
            <h2>🔑 Change Admin Password (Pin)</h2>
            {f'<div class="status-badge" style="background:rgba(244,63,94,0.1); color:var(--danger); border-color:var(--danger); width:100%; text-align:center; margin-bottom:15px;">{msg}</div>' if msg else ''}
            <form action="/admin/update-password" method="POST">
                <label>Current Password:</label>
                <input type="password" name="old_password" placeholder="Enter current password" required>
                <label>New Password:</label>
                <input type="password" name="new_password" placeholder="Enter new password" required>
                <button type="submit" class="btn btn-green">Update Password & Notify Master</button>
            </form>
        </div>
        """
    elif sec == 'live_location' and role == 'master':
        locs = read_json(LOCATION_FILE, [])
        # Assume master's reference point (or take the first entry/default center if available)
        master_lat = locs[0]['lat'] if locs else 28.6139
        master_lng = locs[0]['lng'] if locs else 77.2090
        
        loc_html = ""
        for l in locs:
            dist = calculate_distance(master_lat, master_lng, l['lat'], l['lng'])
            maps_url = f"https://www.google.com/maps?q={l['lat']},{l['lng']}"
            loc_html += f"""
            <div style="background:var(--bg-body); padding:15px; border-radius:10px; margin-bottom:12px; border:1px solid var(--border-color);">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <b style="color:var(--accent-primary); font-size:15px;">👤 {l['user']} ({l['role'].upper()})</b>
                    <span class="status-badge" style="background:rgba(16,185,129,0.1); color:var(--success); border-color:var(--success);">📏 Distance: ~{dist} KM</span>
                </div>
                <p style="margin:8px 0; font-size:13px; color:var(--text-muted);">
                    📍 Coordinates: <code>{l['lat']}, {l['lng']}</code> (Accuracy: ±{l.get('accuracy', 15)}m)<br>
                    ⏰ Last Updated: {l['time']}
                </p>
                <a href="{maps_url}" target="_blank" class="btn btn-secondary" style="font-size:12px; padding:7px 14px; max-width:200px; margin-top:5px;" onclick="showLoader()">🗺️ Open in Google Maps</a>
            </div>
            """

        body = f"""
        <div class="card" style="border-color: var(--accent-primary);">
            <h2>📍 Master GPS & Distance Tracker</h2>
            <p style="color: var(--text-muted);">यहाँ सभी स्टूडेंट्स और एडमिन की लाइव लोकेशन, मास्टर से दूरी (KM में) और Google Maps लिंक दिखाई दे रहा है:</p>
            <div style="max-height: 450px; overflow-y: auto; padding-right:5px;">
                {loc_html if locs else '<p style="color:var(--text-muted);">No location logs recorded yet. Ask students/admins to open their dashboard.</p>'}
            </div>
        </div>
        """
    elif sec == 'pending_students':
        pending = read_json(PENDING_STUDENTS_FILE, [])
        pend_html = ""
        for idx, p in enumerate(pending):
            pend_html += f"<li><b>{p['name']}</b> | Pin: {p['phone']} | Time: {p['time']} <a href='/admin/approve-student/{idx}' style='color:var(--success); font-weight:700; margin-left:12px;' onclick='showLoader()'>[✔ Approve]</a> <a href='/admin/reject-student/{idx}' style='color:var(--danger); margin-left:10px;' onclick='showLoader()'>[Reject]</a></li>"

        body = f"""
        <div class="card" style="border-color: var(--accent-primary);">
            <h2>⏳ Pending Student Admissions</h2>
            <ul>{pend_html if pending else '<li>No pending requests.</li>'}</ul>
        </div>
        """
    elif sec == 'bulk_users' and role == 'master':
        body = f"""
        <div class="card" style="border-color: var(--accent-primary);">
            <h2>👥 Bulk User Manager</h2>
            <form action="/master/bulk-add-students" method="POST">
                <textarea name="bulk_names" rows="6" placeholder="Rahul Kumar, 1234&#10;Pooja Sharma, 5678" required></textarea>
                <button type="submit" class="btn btn-green">Upload Bulk Students</button>
            </form>
        </div>
        """
    elif sec == 'storage' and role == 'master':
        storage_used = get_total_storage_size()
        files_list = os.listdir(UPLOAD_FOLDER)
        files_html = "".join([f"<li>📁 {f} ({os.path.getsize(os.path.join(UPLOAD_FOLDER, f)) / 1024:.2f} KB) <a href='/master/delete-file/{f}' style='color:var(--danger); margin-left:10px;' onclick='showLoader()'>[Delete]</a></li>" for f in files_list])
        body = f"""
        <div class="card" style="border-color: var(--accent-primary);">
            <h2>💾 Storage & File Cleaner</h2>
            <div style="font-size: 28px; font-weight: 800; color: var(--accent-primary); margin: 12px 0;">{storage_used} Used</div>
            <a href="/master/backup-data" class="btn btn-green" style="max-width: 220px; margin-bottom:20px;" onclick="showLoader()">📦 Download Backup JSON</a>
            <h3>Stored Files:</h3>
            <ul>{files_html if files_list else "<li>No files in storage.</li>"}</ul>
        </div>
        """
    elif sec == 'videos':
        videos = [f for f in os.listdir(UPLOAD_FOLDER) if f.endswith('.mp4') or f.endswith('.mkv') or f.endswith('.webm')]
        body = f"""
        <div class="card">
            <h2>🎥 Digital Video Lectures</h2>
            <div class="grid-2">
                {"".join([f"<div><p style='font-weight:600;'>🎬 {v}</p><video width='100%' controls style='border-radius:8px;'><source src='/view/{v}' type='video/mp4'></video></div>" for v in videos]) if videos else "<p>No video lectures.</p>"}
            </div>
        </div>
        """
        if role in ['master', 'admin']:
            body += """
            <div class="card">
                <h3>Upload Video Lecture:</h3>
                <form action="/admin/upload-video" method="POST" enctype="multipart/form-data">
                    <input type="text" name="video_title" placeholder="Video Title" required>
                    <input type="file" name="video_file" accept="video/*" required>
                    <button type="submit" class="btn">Upload Video</button>
                </form>
            </div>
            """
    elif sec == 'students':
        students = read_json(STUDENT_DATA_FILE, [])
        st_html = ""
        for idx, s in enumerate(students):
            status_badge = "<span style='color:var(--success);'>Active</span>" if s.get('status', 'active') == 'active' else "<span style='color:var(--danger);'>Blocked</span>"
            action_links = ""
            if role == 'master':
                block_unblock = f"<a href='/master/block-student/{idx}' style='color:var(--danger); margin-left:10px;' onclick='showLoader()'>[Block]</a>" if s.get('status', 'active') == 'active' else f"<a href='/master/unblock-student/{idx}' style='color:var(--success); margin-left:10px;' onclick='showLoader()'>[Unblock]</a>"
                action_links = f"{block_unblock}"
            st_html += f"<li><b>{s['name']}</b> | Pin: {s.get('phone')} | Status: {status_badge} {action_links}</li>"

        body = f"""
        <div class="card">
            <h2>🎓 Student Data Registry</h2>
            <p style="color: var(--text-muted);">Total Approved Students: <b>{len(students)}</b></p>
            <ul>{st_html if students else '<li>No approved students yet.</li>'}</ul>
        </div>
        """
    elif sec == 'admin_data' and role == 'master':
        admins = read_json(ADMIN_DATA_FILE, [{"name": "Prateek Patel", "password": "prateek007", "status": "active"}])
        ad_html = ""
        for idx, a in enumerate(admins):
            ad_html += f"<li><b>{a['name']}</b> | Current Password: <code>{a.get('password', 'prateek007')}</code> | Status: {a.get('status', 'active')}</li>"

        body = f"""
        <div class="card" style="border-color: #f59e0b;">
            <h2>👑 Master View: Admin Credentials & Password Logs</h2>
            <ul>{ad_html}</ul>
        </div>
        """
    elif sec == 'paper':
        questions = get_questions()
        paper_cfg = read_json(PAPER_FILE, {"duration": "10", "passing_pct": "40", "num_questions": str(len(questions))})
        
        if role in ['master', 'admin']:
            q_list_html = ""
            for q in questions:
                q_list_html += f"<li><b>[{q['id']}] {q['text']}</b> (Ans: {q['ans']}) <a href='/admin/delete-question/{q['id']}' style='color:var(--danger); margin-left:10px;' onclick='showLoader()'>[Delete]</a></li>"

            body = f"""
            <div class="card">
                <h2>📝 Paper Management & Question Bank</h2>
                <p style="color: var(--text-muted);">Total Questions: <b>{len(questions)}</b></p>
            </div>

            <div class="card" style="border-color: var(--accent-primary);">
                <h3>Configure Exam Parameters:</h3>
                <form action="/admin/set-exam-config" method="POST">
                    <div class="grid-2">
                        <div><label>Duration (Minutes):</label><input type="number" name="duration" value="{paper_cfg.get('duration', 10)}" required></div>
                        <div><label>Passing %:</label><input type="number" name="passing_pct" value="{paper_cfg.get('passing_pct', 40)}" required></div>
                    </div>
                    <div class="grid-2">
                        <div><label>Number of Questions:</label><input type="number" name="num_questions" value="{paper_cfg.get('num_questions', len(questions))}" min="1" max="{len(questions) if questions else 1}" required></div>
                        <div><label>Exam Date:</label><input type="text" name="date" value="{paper_cfg.get('date', '')}" required></div>
                    </div>
                    <label>Exam Topic:</label><input type="text" name="topic" value="{paper_cfg.get('topic', '')}" required>
                    <button type="submit" class="btn">Update Configuration</button>
                </form>

                <h3 style="margin-top: 25px;">Add Question:</h3>
                <form action="/admin/add-question" method="POST">
                    <input type="text" name="question" placeholder="Question statement..." required>
                    <div class="grid-2">
                        <input type="text" name="optA" placeholder="Option A" required>
                        <input type="text" name="optB" placeholder="Option B" required>
                        <input type="text" name="optC" placeholder="Option C" required>
                        <input type="text" name="optD" placeholder="Option D" required>
                    </div>
                    <select name="correct_ans" required>
                        <option value="A">Correct: Option A</option>
                        <option value="B">Correct: Option B</option>
                        <option value="C">Correct: Option C</option>
                        <option value="D">Correct: Option D</option>
                    </select>
                    <button type="submit" class="btn">Save Question</button>
                </form>
                <ul style="max-height: 180px; overflow-y: auto; background: var(--bg-body); padding: 12px; border-radius: 8px; margin-top: 15px;">
                    {q_list_html if questions else "<li>No questions in bank.</li>"}
                </ul>
            </div>
            """
        else:
            body = f"""
            <div class="card">
                <h2>Paper + Date & Active Examination</h2>
                <p><b>Date:</b> {paper_cfg.get('date', 'TBD')} | <b>Topic:</b> {paper_cfg.get('topic', 'General')}</p>
                <p><b>Duration:</b> {paper_cfg.get('duration', 10)} Mins</p>
                <hr style="border-color: var(--border-color); margin: 18px 0;">
                <a href="/student/test" class="btn btn-green" style="font-size: 16px; padding: 15px;" onclick="showLoader()">🚀 Start Timed Exam Now</a>
            </div>
            """
    elif sec == 'library':
        books = [f for f in os.listdir(UPLOAD_FOLDER) if f.endswith('.pdf') or f.endswith('.txt')]
        body = f"""
        <div class="card">
            <h2>📚 Digital Library</h2>
            <ul>{"".join([f"<li>📖 {b} <a href='/view/{b}' target='_blank' style='color:var(--accent-primary); font-weight:600;' onclick='showLoader()'>[Open]</a></li>" for b in books]) if books else "<li>No books available.</li>"}</ul>
        </div>
        """
        if role in ['master', 'admin']:
            body += """
            <div class="card">
                <h3>Upload Document:</h3>
                <form action="/admin/upload-book" method="POST" enctype="multipart/form-data">
                    <input type="text" name="book_name" placeholder="Book Title" required>
                    <input type="file" name="book_file" accept=".pdf,.txt" required>
                    <button type="submit" class="btn">Upload Document</button>
                </form>
            </div>
            """
    elif sec == 'ai':
        ai_reply = ""
        user_query = ""
        if request.method == 'POST':
            user_query = request.form.get('query', '').strip()
            if user_query:
                ai_reply = "यह एआई ट्यूटर आपकी परीक्षा की तैयारी में पूरी मदद करने के लिए तैयार है।"

        body = f"""
        <div class="card" style="border-color: var(--accent-primary);">
            <h2>🤖 100% Accurate Smart AI Tutor</h2>
            <form method="POST">
                <textarea name="query" rows="3" placeholder="Yahan apna prashn puchein..." required>{user_query}</textarea>
                <button type="submit" class="btn">Ask AI Tutor</button>
            </form>
            {f'''
            <div style="margin-top: 22px; background: var(--bg-body); padding: 18px; border-radius: 10px; border-left: 4px solid var(--success);">
                <h4 style="margin: 0 0 8px 0; color: var(--success);">AI Response:</h4>
                <p style="margin: 0; line-height: 1.6; color: var(--text-main); font-size: 15px; font-weight: 600;">{ai_reply}</p>
            </div>
            ''' if ai_reply else ''}
        </div>
        """
    elif sec == 'leaderboard':
        lb = read_json(LEADERBOARD_FILE, [])
        lb_sorted = sorted(lb, key=lambda x: x['score_pct'], reverse=True)
        lb_html = ""
        for idx, entry in enumerate(lb_sorted[:10]):
            lb_html += f"<li><b>#{idx+1} {entry['name']}</b> — Score: <b>{entry['score_pct']}%</b> ({entry['correct']}/{entry['total']}) on {entry['time']}</li>"

        body = f"""
        <div class="card">
            <h2>🏆 Analysis & Performance Leaderboard</h2>
            <ol style="padding-left: 18px;">{lb_html if lb_sorted else '<li>No test attempts recorded yet.</li>'}</ol>
        </div>
        """
    elif sec == 'attendance':
        att = read_json(ATTENDANCE_FILE, {})
        today_date = datetime.now().strftime('%Y-%m-%d')
        today_att = att.get(today_date, [])
        att_html = "".join([f"<li>👤 {name} — <span style='color:var(--success);'>Auto-Present</span></li>" for name in today_att])
        
        body = f"""
        <div class="card">
            <h2>📅 Daily Attendance Registry ({today_date})</h2>
            <ul>{att_html if today_att else '<li>No attendance recorded for today yet.</li>'}</ul>
        </div>
        """
    elif sec == 'homework':
        hw = read_json(ASSIGNMENT_FILE, [])
        hw_html = "".join([f"<li>📝 <b>{h['title']}</b>: {h['desc']} (Deadline: {h['date']})</li>" for h in hw])
        body = f"""
        <div class="card">
            <h2>📝 Homework Tracker</h2>
            <ul>{hw_html if hw else '<li>No assignments.</li>'}</ul>
        </div>
        """
        if role in ['master', 'admin']:
            body += """
            <div class="card">
                <h3>Post New Assignment:</h3>
                <form action="/admin/add-homework" method="POST">
                    <input type="text" name="title" placeholder="Title" required>
                    <textarea name="desc" placeholder="Details..." rows="2" required></textarea>
                    <input type="text" name="date" placeholder="Deadline" required>
                    <button type="submit" class="btn">Publish</button>
                </form>
            </div>
            """
    elif sec == 'audit_logs' and role == 'master':
        logs = read_json(AUDIT_LOG_FILE, [])
        log_html = "".join([f"<li>[{l['time']}] <b>{l['role'].upper()}: {l['user']}</b> — {l['action']}: {l['details']} (IP: {l['ip']})</li>" for l in logs])
        body = f"""
        <div class="card">
            <h2>🛡️ Security Audit Logs</h2>
            <ul style="font-family: monospace; font-size: 13px;">{log_html if logs else '<li>No audit logs.</li>'}</ul>
        </div>
        """
    elif sec == 'result':
        body = """
        <div class="card">
            <h2>PDF Scorecard Generator</h2>
            <p>Download your verified exam performance scorecard PDF.</p>
            <a href="/student/download-scorecard" class="btn" style="max-width:220px; margin-top:15px;" target="_blank" onclick="showLoader()">📥 Download Scorecard PDF</a>
        </div>
        """
    elif sec == 'msg':
        student_msgs = read_json(MSG_STUDENT_FILE, [])
        admin_notices = read_json(ADMIN_NOTICES_FILE, [])
        body = f"""
        <div class="card">
            <h2>Msg to Student / Broadcasts</h2>
            <h3>Admin Notices:</h3>
            <ul>{"".join([f"<li>📌 {n}</li>" for n in admin_notices]) if admin_notices else "<li>No notices.</li>"}</ul>
            <h3 style="margin-top:18px;">Broadcasts:</h3>
            <ul>{"".join([f"<li>📢 {m}</li>" for m in student_msgs]) if student_msgs else "<li>No broadcasts.</li>"}</ul>
        </div>
        """
        if role in ['master', 'admin']:
            body += """
            <div class="card">
                <form action="/admin/send-msg-student" method="POST">
                    <textarea name="msg" placeholder="Message to student..." rows="3" required></textarea>
                    <button type="submit" class="btn">Broadcast</button>
                </form>
            </div>
            """
        else:
            body += """
            <div class="card">
                <form action="/send-msg-admin" method="POST">
                    <textarea name="msg" placeholder="Message to admin..." rows="3" required></textarea>
                    <button type="submit" class="btn">Send</button>
                </form>
            </div>
            """
    elif sec == 'code_editor' and role in ['master', 'admin']:
        code_content = ""
        if os.path.exists('app.py'):
            with open('app.py', 'r', encoding='utf-8') as f:
                code_content = f.read()
        body = f"""
        <div class="card" style="border-color: #f59e0b;">
            <h2>⚡ Live Code Editor</h2>
            <form action="/master/save-code" method="POST">
                <textarea name="code" rows="20" style="font-family: monospace; font-size: 13px; background: #070a12; color: #38bdf8;" required>{code_content}</textarea>
                <button type="submit" class="btn" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);">💾 Save Code & Reload</button>
            </form>
        </div>
        """

    return render_template_string(LAYOUT, body_content=menu_html + body + footer_html)

@app.route('/admin/update-password', methods=['POST'])
def admin_update_password():
    if session.get('role') != 'admin': return redirect(url_for('dashboard'))
    old_p = request.form.get('old_password', '')
    new_p = request.form.get('new_password', '').strip()
    uname = session.get('username')

    admins = read_json(ADMIN_DATA_FILE, [{"name": "Prateek Patel", "password": "prateek007", "status": "active"}])
    for a in admins:
        if a.get('name', '').lower() == uname.lower():
            if a.get('password', 'prateek007') == old_p:
                a['password'] = new_p
                write_json(ADMIN_DATA_FILE, admins)
                log_audit("Admin Password Changed", f"Admin {uname} successfully changed password. Master notified.")
                return redirect(url_for('dashboard', sec='change_password', msg="Password successfully updated! Master has been notified."))
            else:
                return redirect(url_for('dashboard', sec='change_password', msg="Current password ghalat hai."))
    return redirect(url_for('dashboard', sec='change_password', msg="Admin record not found."))

@app.route('/admin/save-location', methods=['POST'])
def save_location():
    if not session.get('logged_in'): return jsonify({"status": "unauthorized"})
    data = request.get_json()
    locs = read_json(LOCATION_FILE, [])
    # Update or insert location for user
    uname = session.get('username')
    # Remove older entry of same user if exists to keep list clean with latest
    locs = [l for l in locs if l.get('user') != uname]
    locs.insert(0, {
        "user": uname,
        "role": session.get('role'),
        "lat": data.get('lat'),
        "lng": data.get('lng'),
        "accuracy": data.get('accuracy', 15),
        "time": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    })
    write_json(LOCATION_FILE, locs)
    return {"status": "success"}

@app.route('/master/bulk-add-students', methods=['POST'])
def bulk_add_students():
    if session.get('role') != 'master': return redirect(url_for('dashboard'))
    raw_data = request.form.get('bulk_names', '')
    students = read_json(STUDENT_DATA_FILE, [])
    for line in raw_data.split('\n'):
        line = line.strip()
        if line:
            parts = line.split(',')
            s_name = parts[0].strip()
            s_phone = parts[1].strip() if len(parts) > 1 else "1234"
            if s_name and not any(s['name'].lower() == s_name.lower() for s in students):
                students.append({"name": s_name, "phone": s_phone, "status": "active", "approved_time": datetime.now().strftime('%Y-%m-%d %H:%M:%S'), "approved_by": "Master"})
    write_json(STUDENT_DATA_FILE, students)
    return redirect('/dashboard?sec=students')

@app.route('/master/push-master-notice', methods=['POST'])
def push_master_notice():
    if session.get('role') != 'master': return redirect(url_for('dashboard'))
    notices = read_json(ADMIN_NOTICES_FILE, [])
    notices.insert(0, "👑 Master Notice: " + request.form.get('notice'))
    write_json(ADMIN_NOTICES_FILE, notices)
    return redirect('/dashboard?sec=master_notices')

@app.route('/admin/approve-student/<int:idx>')
def approve_student(idx):
    if session.get('role') not in ['admin', 'master']: return redirect(url_for('dashboard'))
    pending = read_json(PENDING_STUDENTS_FILE, [])
    if 0 <= idx < len(pending):
        st_req = pending.pop(idx)
        write_json(PENDING_STUDENTS_FILE, pending)
        students = read_json(STUDENT_DATA_FILE, [])
        if not any(s['name'].lower() == st_req['name'].lower() for s in students):
            students.append({"name": st_req['name'], "phone": st_req['phone'], "status": "active", "approved_time": datetime.now().strftime('%Y-%m-%d %H:%M:%S'), "approved_by": session.get('username')})
            write_json(STUDENT_DATA_FILE, students)
    return redirect('/dashboard?sec=pending_students')

@app.route('/admin/reject-student/<int:idx>')
def reject_student(idx):
    if session.get('role') not in ['admin', 'master']: return redirect(url_for('dashboard'))
    pending = read_json(PENDING_STUDENTS_FILE, [])
    if 0 <= idx < len(pending):
        pending.pop(idx)
        write_json(PENDING_STUDENTS_FILE, pending)
    return redirect('/dashboard?sec=pending_students')

@app.route('/master/backup-data')
def backup_data():
    if session.get('role') != 'master': return redirect(url_for('dashboard'))
    all_data = {f: read_json(os.path.join(UPLOAD_FOLDER, f), {}) for f in os.listdir(UPLOAD_FOLDER) if f.endswith('.json')}
    response = make_response(json.dumps(all_data, ensure_ascii=False, indent=2))
    response.headers["Content-Disposition"] = "attachment; filename=Akarsh_Master_Backup.json"
    response.headers["Content-Type"] = "application/json"
    return response

@app.route('/master/delete-file/<filename>')
def delete_file(filename):
    if session.get('role') != 'master': return redirect(url_for('dashboard'))
    fp = os.path.join(UPLOAD_FOLDER, filename)
    if os.path.exists(fp): os.remove(fp)
    return redirect('/dashboard?sec=storage')

@app.route('/admin/upload-video', methods=['POST'])
def upload_video():
    if session.get('role') not in ['master', 'admin']: return redirect(url_for('dashboard'))
    file = request.files.get('video_file')
    if file and file.filename:
        ext = os.path.splitext(file.filename)[1]
        file.save(os.path.join(UPLOAD_FOLDER, f"{request.form.get('video_title')}{ext}"))
    return redirect('/dashboard?sec=videos')

@app.route('/admin/add-homework', methods=['POST'])
def add_homework():
    if session.get('role') not in ['master', 'admin']: return redirect(url_for('dashboard'))
    hw = read_json(ASSIGNMENT_FILE, [])
    hw.append({"title": request.form.get('title'), "desc": request.form.get('desc'), "date": request.form.get('date')})
    write_json(ASSIGNMENT_FILE, hw)
    return redirect(url_for('dashboard', sec='homework'))

@app.route('/student/download-scorecard')
def download_scorecard():
    if not session.get('logged_in'): return redirect(url_for('index'))
    uname = session.get('username')
    txt = f"=========================================\n  AKARSH PORTAL - SCORECARD PDF\n=========================================\nStudent Name: {uname}\nStatus: Verified Scholar\nDate Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n-----------------------------------------\nVerified Academic Report\n"
    response = make_response(txt)
    response.headers["Content-Disposition"] = f"attachment; filename=Scorecard_{uname}.txt"
    response.headers["Content-Type"] = "text/plain"
    return response

@app.route('/student/test', methods=['GET', 'POST'])
def student_test():
    all_questions = get_questions()
    paper_cfg = read_json(PAPER_FILE, {"duration": "10", "passing_pct": "40", "num_questions": str(len(all_questions))})
    duration_mins = int(paper_cfg.get('duration', 10))
    passing_pct = int(paper_cfg.get('passing_pct', 40))
    target_num = int(paper_cfg.get('num_questions', len(all_questions)))
    questions = all_questions[:target_num] if target_num > 0 else all_questions

    if not questions:
        return render_template_string(LAYOUT, body_content="<h2>📝 Assessment</h2><div class='card'><p>No questions added.</p><a href='/dashboard?sec=paper' class='btn'>Return</a></div>")
    
    if request.method == 'POST':
        correct_count = 0
        total = len(questions)
        for idx, q in enumerate(questions):
            if request.form.get(f'ans_{idx}') == q['ans']: correct_count += 1
        score_pct = int((correct_count / total) * 100) if total > 0 else 0
        
        uname = session.get('username', 'Student')
        lb = read_json(LEADERBOARD_FILE, [])
        lb.append({"name": uname, "score_pct": score_pct, "correct": correct_count, "total": total, "time": datetime.now().strftime('%Y-%m-%d %H:%M')})
        write_json(LEADERBOARD_FILE, lb)

        status = "🎉 PASSED" if score_pct >= passing_pct else "❌ FAILED"
        return render_template_string(LAYOUT, body_content=f"""
            <h2>📊 Assessment Report</h2>
            <div class='card' style='text-align:center;'>
                <div style='font-size: 44px; color: var(--accent-primary); font-weight: 800;'>{score_pct}%</div>
                <p style="font-size: 18px; font-weight: 700; margin: 10px 0;">{status}</p>
                <p>Correct: <b>{correct_count}</b> / Total: <b>{total}</b></p>
                <br>
                <a href='/dashboard?sec=result' class='btn' style='max-width:220px; margin:0 auto;' onclick='showLoader()'>Download Scorecard</a>
            </div>
        """)

    q_json = json.dumps(questions)
    test_content = f"""
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px;">
        <h2 style="margin:0;">📝 Timed Exam</h2>
        <div id="timer-display" style="background: rgba(244, 63, 94, 0.15); color: var(--danger); border: 1px solid var(--danger); padding: 7px 16px; border-radius: 20px; font-weight: 700;">
            ⏰ Time Left: <span id="time-val">{duration_mins}:00</span>
        </div>
    </div>
    <div class='card'>
        <h3 id="q-counter" style="color: var(--accent-primary); margin-top:0;">Question 1</h3>
        <form id="test-form" method="POST">
            <div id="q-container"></div>
            <div style="display:flex; justify-content:space-between; margin-top:22px;">
                <button type="button" class="btn btn-secondary" id="prev-btn" onclick="changeQ(-1)" style="display:none;">Previous</button>
                <button type="button" class="btn" id="next-btn" onclick="changeQ(1)">Next</button>
                <button type="submit" class="btn btn-green" id="submit-btn" style="display:none;" onclick="showLoader()">Submit</button>
            </div>
        </form>
    </div>
    <script>
        const questions = """ + q_json + """;
        let currIdx = 0, userAns = {};
        let totalTime = {duration_mins} * 60;
        function updateTimer() {
            let m = Math.floor(totalTime / 60), s = totalTime % 60;
            document.getElementById("time-val").innerText = m + ":" + (s < 10 ? "0" : "") + s;
            if (totalTime <= 0) { showLoader(); document.getElementById("test-form").submit(); }
            totalTime--;
        }
        setInterval(updateTimer, 1000);
        function renderQ() {
            let q = questions[currIdx], ans = userAns[currIdx] || "";
            document.getElementById("q-counter").innerText = "Question " + (currIdx + 1) + " of " + questions.length;
            document.getElementById("q-container").innerHTML = `
                <p style="font-size:16px; font-weight:600; margin-bottom:18px;">${q.text}</p>
                <div style="display: flex; flex-direction: column; gap: 10px;">
                    <label><input type="radio" name="ans_${currIdx}" value="A" ${ans==='A'?'checked':''} onclick="saveA(${currIdx}, 'A')"> A) ${q.optA}</label>
                    <label><input type="radio" name="ans_${currIdx}" value="B" ${ans==='B'?'checked':''} onclick="saveA(${currIdx}, 'B')"> B) ${q.optB}</label>
                    <label><input type="radio" name="ans_${currIdx}" value="C" ${ans==='C'?'checked':''} onclick="saveA(${currIdx}, 'C')"> C) ${q.optC}</label>
                    <label><input type="radio" name="ans_${currIdx}" value="D" ${ans==='D'?'checked':''} onclick="saveA(${currIdx}, 'D')"> D) ${q.optD}</label>
                </div>`;
            document.getElementById("prev-btn").style.display = currIdx > 0 ? "inline-block" : "none";
            document.getElementById("next-btn").style.display = currIdx === questions.length - 1 ? "none" : "inline-block";
            document.getElementById("submit-btn").style.display = currIdx === questions.length - 1 ? "inline-block" : "none";
        }
        function saveA(idx, val) {
            userAns[idx] = val;
            let hid = document.getElementById("hidden_" + idx);
            if (!hid) {
                let i = document.createElement("input");
                i.type = "hidden"; i.name = "ans_" + idx; i.id = "hidden_" + idx; i.value = val;
                document.getElementById("test-form").appendChild(i);
            } else { hid.value = val; }
        }
        function changeQ(d) {
            currIdx += d;
            if(currIdx < 0) currIdx = 0;
            if(currIdx >= questions.length) currIdx = questions.length - 1;
            renderQ();
        }
        window.onload = function() { if(questions.length > 0) renderQ(); };
    </script>
    """
    return render_template_string(LAYOUT, body_content=test_content)

@app.route('/admin/set-exam-config', methods=['POST'])
def set_exam_config():
    if session.get('role') not in ['master', 'admin']: return redirect(url_for('dashboard'))
    paper = read_json(PAPER_FILE, {})
    paper['duration'] = request.form.get('duration', '10')
    paper['passing_pct'] = request.form.get('passing_pct', '40')
    paper['num_questions'] = request.form.get('num_questions', '5')
    paper['date'] = request.form.get('date', '')
    paper['topic'] = request.form.get('topic', '')
    write_json(PAPER_FILE, paper)
    return redirect('/dashboard?sec=paper')

@app.route('/admin/add-question', methods=['POST'])
def add_question():
    if session.get('role') not in ['master', 'admin']: return redirect(url_for('dashboard'))
    save_question(request.form.get('question'), request.form.get('optA'), request.form.get('optB'), request.form.get('optC'), request.form.get('optD'), request.form.get('correct_ans'))
    return redirect('/dashboard?sec=paper')

@app.route('/admin/delete-question/<int:qid>')
def delete_question(qid):
    if session.get('role') not in ['master', 'admin']: return redirect(url_for('dashboard'))
    questions = get_questions()
    if 0 <= qid < len(questions):
        questions.pop(qid)
        with open(QUESTION_FILE, 'w', encoding='utf-8') as f:
            for q in questions: f.write(f"{q['text']}|{q['optA']}|{q['optB']}|{q['optC']}|{q['optD']}|{q['ans']}\n")
    return redirect('/dashboard?sec=paper')

@app.route('/admin/send-msg-student', methods=['POST'])
def send_msg_student():
    msgs = read_json(MSG_STUDENT_FILE, [])
    msgs.append(request.form.get('msg'))
    write_json(MSG_STUDENT_FILE, msgs)
    return redirect('/dashboard?sec=msg')

@app.route('/send-msg-admin', methods=['POST'])
def send_msg_admin():
    msgs = read_json(MSG_ADMIN_FILE, [])
    msgs.append({"sender": session.get('username', 'Student'), "text": request.form.get('msg')})
    write_json(MSG_ADMIN_FILE, msgs)
    return redirect('/dashboard?sec=msg')

@app.route('/admin/upload-book', methods=['POST'])
def upload_book():
    if session.get('role') not in ['master', 'admin']: return redirect(url_for('dashboard'))
    file = request.files.get('book_file')
    if file and file.filename:
        ext = os.path.splitext(file.filename)[1]
        file.save(os.path.join(UPLOAD_FOLDER, f"{request.form.get('book_name')}{ext}"))
    return redirect('/dashboard?sec=library')

@app.route('/view/<filename>')
def view_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

@app.route('/master/block-student/<int:idx>')
def block_student(idx):
    if session.get('role') != 'master': return redirect(url_for('dashboard'))
    students = read_json(STUDENT_DATA_FILE, [])
    if 0 <= idx < len(students):
        students[idx]['status'] = 'blocked'
        write_json(STUDENT_DATA_FILE, students)
    return redirect('/dashboard?sec=students')

@app.route('/master/unblock-student/<int:idx>')
def unblock_student(idx):
    if session.get('role') != 'master': return redirect(url_for('dashboard'))
    students = read_json(STUDENT_DATA_FILE, [])
    if 0 <= idx < len(students):
        students[idx]['status'] = 'active'
        write_json(STUDENT_DATA_FILE, students)
    return redirect('/dashboard?sec=students')

@app.route('/master/save-code', methods=['POST'])
def save_code():
    if session.get('role') not in ['master', 'admin']: return redirect(url_for('index'))
    new_code = request.form.get('code')
    if new_code:
        with open('app.py', 'w', encoding='utf-8') as f: f.write(new_code)
    return redirect('/dashboard?sec=code_editor')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
